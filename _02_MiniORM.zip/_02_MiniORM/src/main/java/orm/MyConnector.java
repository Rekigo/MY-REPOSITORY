package orm;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


/*
class Singleton{
    private static Singleton instance;

    private Singleton(){}

    private static Singleton create(){}

    public static Singleton getInstance(){
        if (instance == null){
            instance = create();
        }
        return instance;
    }
}
*/



public class MyConnector {
    private static Connection connection;
    private MyConnector(){}
    private static final String CONNECTION_STRING = "jdbc:mysql://localhost:3306/%s";

    public static void createConnection(String username, String password, String dbName) throws SQLException {

      /*  Properties properties = new Properties();
        properties.setProperty("user", username);
        properties.setProperty("password", password);

        connection = DriverManager.getConnection(connectionString + dbNane, properties);

        */

        //or

        String jdbcString = String.format(CONNECTION_STRING, dbName);

        connection = DriverManager.getConnection(jdbcString, username, password);
    }

    public static Connection getConnection() {
        return connection;
    }
}
