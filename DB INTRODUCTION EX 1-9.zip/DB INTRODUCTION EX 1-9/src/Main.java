import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.*;

/*public class Main {
    public static void main(String[] args) throws SQLException {
        //DB connection creation
        Properties properties = new Properties();
        properties.setProperty("user","root");
        properties.setProperty("password","root");
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/minions_db", properties);

        //Statement logic-> create query or test



        ResultSet resultSet = connection.createStatement().executeQuery("SELECT v.name, COUNT(mv.minion_id) AS minion_count FROM villains v " +
                "JOIN minions_villains mv ON v.id = mv.villain_id " +
                "GROUP BY v.name " +
                "HAVING COUNT(mv.minion_id) > 15 " +
                "ORDER BY minion_count DESC");
        while(!resultSet.next()) {
            System.out.printf("%s %d",resultSet.getString(1),resultSet.getInt(2)).append(System.lineSeparator());
        }


    }
}*///*
public class Main {
    private static final DBTools DB_Tools = new DBTools("root", "root", "minions_db");

    private static final BufferedReader READER = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws SQLException, IOException {
        excercise_09();
    }

    private static void excercise_09() throws SQLException, IOException {
        CallableStatement callableStatement = DB_Tools.getConnection().prepareCall("CALL usp_get_older(?)");
        callableStatement.setInt(1,Integer.parseInt(READER.readLine()));
        ResultSet resultSet = callableStatement.executeQuery();
        resultSet.next();
        System.out.println(resultSet.getString(1)+ " " + resultSet.getInt(2));
    }

    private static void excercise_08() throws IOException, SQLException {
        int[] minionIds = Arrays.stream(READER.readLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        DB_Tools.getConnection().nativeSQL("");
        Arrays.stream(minionIds).forEach(id -> {
            String sql = "UPDATE minions SET name = LOWER(name),age = age + 1 WHERE id = ?";
            try {
                PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement(sql);
                preparedStatement.setInt(1, id);
                preparedStatement.executeUpdate();

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private static void excercise_07() throws SQLException {
        ResultSet resultSet = DB_Tools.getConnection().createStatement().executeQuery("SELECT name FROM minions");
        ArrayDeque<String> deque = new ArrayDeque<>();
        while (resultSet.next()) {
deque.add(resultSet.getString(1));
        }
        while (!deque.isEmpty()){
        System.out.println(deque.removeFirst());
        if(!deque.isEmpty()){
            System.out.println(deque.removeLast());
        }
    }
    }

    private static void excercise_06() throws IOException, SQLException {
       int villainId =Integer.parseInt(READER.readLine());
        String villainName = findVillainNameById(villainId);

        if (villainName.isEmpty()){
            System.out.println("No such villain was found");
        }else{
            int releasedMinionsCount = releaseMinions(villainId);
            deleteVillain(villainId);
            System.out.printf("%s was deleted%n%d minions released", villainName, releasedMinionsCount);
        }
    }

    private static void deleteVillain(int villainId) throws SQLException {
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("DELETE FROM villains WHERE id = ?");
        preparedStatement.setInt(1, villainId);
        preparedStatement.executeUpdate();


    }

    private static int releaseMinions(int villainId) throws SQLException {
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("DELETE FROM minions_villains WHERE villain_id = ?");
        preparedStatement.setInt(1, villainId);

        return preparedStatement.executeUpdate();
    }

    private static String findVillainNameById(int villainId) throws SQLException {
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("SELECT name FROM villains WHERE id = ?");
        preparedStatement.setInt(1, villainId);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            return resultSet.getString("name");
        }
        return "";
    }

    private static void excercise_05() throws IOException, SQLException {
        String country = READER.readLine();
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("UPDATE towns SET name = UPPER(name) WHERE country = ?");
        preparedStatement.setString(1, country);
        int i = preparedStatement.executeUpdate();
        if (i == 0 ){
            System.out.println("No town names were effected.");
        }else{
            System.out.printf("%d town names were affected.%n", i);
            preparedStatement = DB_Tools.getConnection().prepareStatement("SELECT name FROM towns WHERE country = ?");
            preparedStatement.setString(1, country);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<String> names = new ArrayList<>();
            while (resultSet.next()){
                names.add(resultSet.getString("name"));
            }
            System.out.printf("[%s]", String.join(", ", names));
        }
    }

    public static void excercise_04() throws IOException, SQLException {
        String[] minionsTokens = READER.readLine().split("\\s+");
        String minionsName = minionsTokens[1];
        int minionAge = Integer.parseInt(minionsTokens[2]);
        String townName = minionsTokens[3];

        String villainName = READER.readLine().split("\\s+")[1];

        int townId = findTownIdByName(townName);
        if (townId == 0) {
//todo create town
            createTown(townName);
            System.out.printf("Town %s was added to the  database.%n", townName);

        }
       int minionId =  createMinion(minionsName,minionAge,townId);
int villainId = findTownIdByName(villainName) ;
if (villainId == 0 ){
    villainId = createVillain(villainName);
    System.out.printf("Villain %s was added to the database.%n", villainName);
}
pupulateMinionsVillains(minionId, villainId);
        System.out.printf("Successfully added %s to be minion of %s",
                minionsName,
                villainName);
    }

    private static void pupulateMinionsVillains(int minionId, int villainId) throws SQLException {
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("INSERT INTO minions_villains VALUE (?, ?)");
        preparedStatement.setInt(1, minionId);
        preparedStatement.setInt(2, villainId);
        preparedStatement.executeUpdate();
    }

    private static int createVillain(String villainName) throws SQLException {
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("INSERT INTO villains (name, evilness_factor) VALUE (?,'evil')");
        preparedStatement.setString(1, villainName);
        preparedStatement.executeUpdate();
        preparedStatement = DB_Tools.getConnection().prepareStatement("SELECT id FROM villains WHERE name = ?");
        preparedStatement.setString(1, villainName);
        ResultSet resultSet = preparedStatement.executeQuery();
        resultSet.next();

        return resultSet.getInt("id");
    }


    private static int findVillainByName(String villainName) throws SQLException {
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("SELECT id FROM villains WHERE name = ?");
        ResultSet resultSet = preparedStatement.executeQuery();
        preparedStatement.setString(1, villainName);
        if (resultSet.next()) {
            return resultSet.getInt("id");
        }
        return 0;
    }

    private static int createMinion(String minionsName, int minionAge, int townId) throws SQLException {
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("INSERT INTO minions(name, age, town_id) VALUE(?, ?, ?)");
        preparedStatement.setString(1, minionsName);
        preparedStatement.setInt(2, minionAge);
        preparedStatement.setInt(3, townId);
        preparedStatement.executeUpdate();
        preparedStatement = DB_Tools.getConnection().prepareStatement("SELECT * FROM minions WHERE name = ?");
        preparedStatement.setString(1, minionsName);

        ResultSet resultSet = preparedStatement.executeQuery();
        resultSet.next();

        return resultSet.getInt("id");

    }

    private static int createTown(String townName) throws SQLException {
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("INSERT INTO towns(name) VALUE(?)");
        preparedStatement.setString(1,townName);
        preparedStatement.executeUpdate();
        preparedStatement = DB_Tools.getConnection().prepareStatement("SELECT id FROM towns WHERE name = ?");
preparedStatement.setString(1,townName);
ResultSet resultSet = preparedStatement.executeQuery();
resultSet.next();
        return resultSet.getInt("id");
    }


    private static Integer findTownIdByName(String townName) throws SQLException {
        PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement("SELECT id FROM towns WHERE name = ?");
preparedStatement.setString(1, townName);
PreparedStatement preparedStatement1 = preparedStatement;
ResultSet resultSet = preparedStatement1.executeQuery();

if(resultSet.next()) {
       return resultSet.getInt("id");
}
        return 0;
    }






    private static void excercise_03() throws IOException, SQLException {
int villainId = Integer.parseInt(READER.readLine());


String sql = "SELECT name FROM villains WHERE id = ?";
PreparedStatement preparedStatement = DB_Tools.getConnection().prepareStatement(sql);
preparedStatement.setInt(1,villainId);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (!resultSet.next()){
            System.out.printf("No villain with Id %d exists in database.", villainId);
            return;
        }
        String villainName = resultSet.getString("name");
        System.out.println("Villain: " + villainName);
        sql = "SELECT m.name, m.age FROM minions m " +
                "JOIN minions_villains mv ON m.id = mv.minion_id " +
                "WHERE villain_id = ?";

        preparedStatement = DB_Tools.getConnection().prepareStatement(sql);
        preparedStatement.setInt(1,villainId);
        resultSet=preparedStatement.executeQuery();
        int index = 0;
        while (resultSet.next()){
            System.out.printf("%d. %s %d",
                    ++index, resultSet.getString("name"),
                    resultSet.getInt("age"))
                    .append(System.lineSeparator());
        }
    }

    public static void excercise_02() throws SQLException{
            String sql = "SELECT v.name, COUNT(mv.minion_id) AS minion_count FROM villains v " +
                    "JOIN minions_villains mv ON v.id = mv.villain_id " +
                    "GROUP BY v.name " +
                    "HAVING COUNT(mv.minion_id) > 15 " +
                    "ORDER BY minion_count DESC";
            ResultSet resultSet = DB_Tools.getConnection().createStatement().executeQuery(sql);




        while (resultSet.next()){
            System.out.printf("%s %d",resultSet.getString(1),resultSet.getInt(2)).append(System.lineSeparator());
        }
    }
}
